from django.apps import AppConfig


class PsdConfig(AppConfig):
    default_auto_field = "django.db.models.BigAutoField"
    name = "psd"
